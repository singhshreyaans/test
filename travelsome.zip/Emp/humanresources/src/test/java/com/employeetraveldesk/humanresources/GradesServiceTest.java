package com.employeetraveldesk.humanresources;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.employeetraveldesk.humanresources.model.Grades;
import com.employeetraveldesk.humanresources.repository.GradesRepository;
import com.employeetraveldesk.humanresources.service.GradesService;
@SpringBootTest
@RunWith(SpringRunner.class)
public class GradesServiceTest {

    @Autowired
    private GradesService gradesService;

    @MockBean
    private GradesRepository gradesRepository;

    @Test
    public void getGradesList_Success() {
        // Given
        Grades grade1 = new Grades(1, "Grade A");
        Grades grade2 = new Grades(2, "Grade B");
        List<Grades> gradesList = Arrays.asList(grade1, grade2);

        when(gradesRepository.findAll()).thenReturn(gradesList);

        // When
        List<Grades> result = gradesService.getGradesList();

        // Then
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getId());
        assertEquals("Grade A", result.get(0).getName());
        assertEquals(2, result.get(1).getId());
        assertEquals("Grade B", result.get(1).getName());
    }

}