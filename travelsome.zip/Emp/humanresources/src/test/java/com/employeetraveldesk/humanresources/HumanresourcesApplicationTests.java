package com.employeetraveldesk.humanresources;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import com.employeetraveldesk.humanresources.exception.InvalidResourceException;
import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.Grades;
import com.employeetraveldesk.humanresources.model.GradesHistory;
import com.employeetraveldesk.humanresources.model.Users;
import com.employeetraveldesk.humanresources.repository.GradesHistoryRepository;
import com.employeetraveldesk.humanresources.repository.UsersRepository;
import com.employeetraveldesk.humanresources.service.UsersService;
import com.employeetraveldesk.humanresources.service.implementation.GradesHistoryServiceImplementation;
import com.employeetraveldesk.humanresources.service.implementation.UsersServiceImplementation;

@SpringBootTest
@ActiveProfiles("test")
class HumanresourcesApplicationTests {
	
	
	@MockBean
    private UsersRepository usersRepository;
	
	

    @Autowired
    private UsersServiceImplementation usersService;
    
    @Test
    public void testUsersServiceImpl() {
        Users user = new Users();
        user.setEmployeeid(123456);
        user.setFirstname("Test");
        user.setLastname("User");
        user.setPhonenumber("123-456-7890");
        user.setEmailAddress("test.user@cognizant.com");
        user.setRole("Employee");

        Mockito.when(usersRepository.findById(123456)).thenReturn(java.util.Optional.of(user));

        Users fetchedUser = usersService.getEmployeeById(123456);
        assertEquals(user, fetchedUser);
    }


	
	
//	 @Test
//	    void testUserServiceImpl() {
//	        // Arrange
//	        UsersRepository usersRepository = Mockito.mock(UsersRepository.class);
//	        GradesHistoryServiceImplementation gradesHistoryServiceImpl = Mockito.mock(GradesHistoryServiceImplementation.class);
//	        UsersService usersService = new UsersServiceImplementation();
//	        
//	        Users user1 = new Users(123456, "Amit", "Juneja", "1234567890", "amit@cognizant.com", "Employee", new Grades(1, "Grade 1"), new ArrayList<>());
//	        Users user2 = new Users(234567, "Sumit", "Mishra", "2345678901", "sumit@cognizant.com", "Manager", new Grades(2, "Grade 2"), new ArrayList<>());
//	        Users user3 = new Users(345678, "Rajesh", "Kumar", "3456789012", "rajesh@cognizant.com", "TravelDeskExec", new Grades(0, "Grade 0"), new ArrayList<>());
//	        
//	        List<Users> usersList = new ArrayList<>();
//	        usersList.add(user1);
//	        usersList.add(user2);
//	        usersList.add(user3);
//	        
//	        Mockito.when(usersRepository.findAll()).thenReturn(usersList);
//	        Mockito.when(usersRepository.findById(user1.getEmployeeid())).thenReturn(Optional.of(user1));
//	        Mockito.when(usersRepository.findById(user2.getEmployeeid())).thenReturn(Optional.of(user2));
//	        Mockito.when(usersRepository.findById(user3.getEmployeeid())).thenReturn(Optional.of(user3));
//	        Mockito.when(usersRepository.findById(999999)).thenReturn(Optional.empty());
//	        
//	        // Act and Assert
//	        Users users1 = usersService.getEmployeeById(user1.getEmployeeid());
//	        assertEquals("Amit", users1.getFirstname());
//	        
//	       Users users2 = usersService.getEmployeeById(user2.getEmployeeid());
//	       assertEquals("Sumit", users2.getFirstname());
//	        
//	        assertThrows(ResourceNotFoundException.class, () -> usersService.getEmployeeById(999999));
//	        
//	        assertTrue(usersService.addEmployee(user1));
//	        assertTrue(usersService.addEmployee(user2));
//	        assertTrue(usersService.addEmployee(user3));
//	        
//	        List<Users> usersListAfterAdd = usersService.getEmployees();
//	        assertEquals(3, usersListAfterAdd.size());
//	        
//	        assertTrue(usersService.updateEmployee(user1.getEmployeeid(), user1));
//	        assertTrue(usersService.updateEmployee(user2.getEmployeeid(), user2));
//	        assertTrue(usersService.updateEmployee(user3.getEmployeeid(), user3));
//	        
//	        List<Users> usersListAfterUpdate = usersService.getEmployees();
//	        assertEquals(3, usersListAfterUpdate.size());
//	        
//	        assertTrue(usersService.deleteEmployeeById(user1.getEmployeeid()));
//	        assertTrue(usersService.deleteEmployeeById(user2.getEmployeeid()));
//	        assertTrue(usersService.deleteEmployeeById(user3.getEmployeeid()));
//	        
//	        List<Users> usersListAfterDelete = usersService.getEmployees();
//	        assertTrue(usersListAfterDelete.isEmpty());
//	    }
    
    
    
    @MockBean
    private GradesHistoryRepository gradesHistoryRepository;

   
    @MockBean
    private GradesHistoryServiceImplementation gradesHistoryServiceImpl;

    
    
//    @Test
//    public void testGradesHistoryServiceImpl() {
//        GradesHistory gradesHistory = new GradesHistory(0, null, null, null);
//        int employeeId = 123456;
//        Grades grades = new Grades(1, "Grade 1");
//
//        Users user = new Users(employeeId, "Test", "User", "1234567890", "test.user@cognizant.com", "Employee", grades, new ArrayList<>());
//        GradesHistory savedGradesHistory = new GradesHistory(1, LocalDate.now(), user, grades);
//
//        Mockito.when(usersRepository.findById(employeeId)).thenReturn(java.util.Optional.of(user));
//        Mockito.when(gradesHistoryRepository.findByEmployeeid(employeeId)).thenReturn(java.util.Optional.of(gradesHistory));
//        Mockito.when(gradesHistoryRepository.save(gradesHistory)).thenReturn(savedGradesHistory);
//
//        GradesHistory createdGradesHistory = usersService.createGradesHistoryByEmployeeid(employeeId);
//        assertEquals(savedGradesHistory, createdGradesHistory);
//    }

    @Test
    public void testUpdateGradesHistoryByEmployeeId_InvalidResourceException() {
        int employeeId = 12345;
        Users user = new Users();
        user.setEmployeeid(employeeId);
        user.setCurrentGrades(new Grades(1, "Grade 1"));

        Mockito.when(usersRepository.findById(employeeId)).thenReturn(java.util.Optional.of(user));

        assertThrows(InvalidResourceException.class, () -> usersService.updateEmployee(employeeId, user));
    }

    @Test
    public void testUpdateGradesHistoryByEmployeeId_ResourceNotFoundException() {
        int employeeId = 123456;
        Users user = new Users();
        user.setEmployeeid(employeeId);
        user.setCurrentGrades(new Grades(1, "Grade 1"));
        GradesHistory gradesHistory = new GradesHistory(employeeId, null, user, null);
        gradesHistory.setEmployeeid(user);
        gradesHistory.setGrades(user.getCurrentGrades());

        Mockito.when(usersRepository.findById(employeeId)).thenReturn(Optional.empty());
        Mockito.when(gradesHistoryServiceImpl.findByEmployeeid(employeeId)).thenReturn(Optional.of(gradesHistory));

        assertThrows(ResourceNotFoundException.class, () -> usersService.updateEmployee(employeeId, user));
    }
    
    

	@Test
	void contextLoads() {
	}

}
