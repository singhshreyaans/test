package com.employeetraveldesk.humanresources.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Users {
	@Id
	private int employeeid;
	private String firstname;
	private String lastname;
	private String phonenumber;
	private String emailAddress;
	private String role;
	@ManyToOne
	@JoinColumn(name="currentgradeid")
	private Grades currentGrades;
	
	@OneToMany(mappedBy="employeeid")
	private List<GradesHistory> gradesHistory;
	
	
	public Users() {
    }

	
	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Grades getCurrentGrades() {
		return currentGrades;
	}

	public void setCurrentGrades(Grades currentGrades) {
		this.currentGrades = currentGrades;
	}

	public List<GradesHistory> getGradesHistory() {
		return gradesHistory;
	}

	public void setGradesHistory(List<GradesHistory> gradesHistory) {
		this.gradesHistory = gradesHistory;
	}

	public Users(int employeeid, String firstname, String lastname, String phonenumber, String emailAddress,
			String role, Grades currentGrades, List<GradesHistory> gradesHistory) {
		super();
		this.employeeid = employeeid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phonenumber = phonenumber;
		this.emailAddress = emailAddress;
		this.role = role;
		this.currentGrades = currentGrades;
		this.gradesHistory = gradesHistory;
	}
	
	

}
