package com.employeetraveldesk.humanresources.service;

import com.employeetraveldesk.humanresources.exception.DuplicateResourceException;
import com.employeetraveldesk.humanresources.exception.InvalidResourceException;
import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.Users;

public interface GradesHistoryService {
	void createGradesHistoryByEmployeeid(int employeeId) throws DuplicateResourceException, InvalidResourceException;
	boolean updateGradesHistoryByEmployeeId(int employeeId, Users users)  throws ResourceNotFoundException;
}
