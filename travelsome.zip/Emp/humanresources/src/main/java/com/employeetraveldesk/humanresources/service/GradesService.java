package com.employeetraveldesk.humanresources.service;

import java.util.List;

import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.Grades;
//import com.employeetraveldesk.humanresources.model.Users;

public interface GradesService {
	List<Grades> getGradesList() throws ResourceNotFoundException;
	
}
