package com.employeetraveldesk.humanresources.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeetraveldesk.humanresources.model.Grades;
import com.employeetraveldesk.humanresources.service.GradesService;

@RestController
@RequestMapping("/api/grades")
public class GradesController {
	
	@Autowired
	GradesService gradesService;

	@GetMapping("/grade")
	public List<Grades> getGradesList() {
		return gradesService.getGradesList();
	}

}
