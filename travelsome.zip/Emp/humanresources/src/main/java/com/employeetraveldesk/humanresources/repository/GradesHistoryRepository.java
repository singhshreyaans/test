package com.employeetraveldesk.humanresources.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeetraveldesk.humanresources.model.GradesHistory;
import com.employeetraveldesk.humanresources.model.Users;

@Repository
public interface GradesHistoryRepository extends JpaRepository<GradesHistory, Integer>{
//	Optional<GradesHistory>findbyEmployeeid(int employeeId);

	Optional<GradesHistory> findByEmployeeid(Users users);
	

}
