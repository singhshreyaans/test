package com.employeetraveldesk.humanresources.service.implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeetraveldesk.humanresources.exception.DuplicateResourceException;
import com.employeetraveldesk.humanresources.exception.InvalidResourceException;
import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.GradesHistory;
import com.employeetraveldesk.humanresources.model.Users;
import com.employeetraveldesk.humanresources.repository.UsersRepository;
import com.employeetraveldesk.humanresources.service.UsersService;

@Service
public class UsersServiceImplementation implements UsersService {

	@Autowired
	UsersRepository usersRepository;

	@Autowired
	GradesHistoryServiceImplementation gradesServiceImpl;

	@Override
	public List<Users> getEmployees() throws ResourceNotFoundException {
		List<Users> users = usersRepository.findAll();
		if (users.size() == 0) {
			throw new ResourceNotFoundException("No employee data, Check database");
		}
		return users;
	}

	@Override
	public boolean addEmployee(Users users) throws DuplicateResourceException, InvalidResourceException {
		Optional<Users> employeeCheck = usersRepository.findById(users.getEmployeeid());
		if (employeeCheck.isPresent()) {
			throw new DuplicateResourceException("Resource already exists");
		}
		if (users.getEmployeeid() < 100000) {
			throw new InvalidResourceException("The entered employee id must be 6 digits");
		}
		if (!this.checkEmail(users.getEmailAddress())) {
			throw new InvalidResourceException("Your email id must have @cognizant.com in email");
		}
		if (users.getRole().equalsIgnoreCase("TravelDeskExec") && users.getCurrentGrades().getId() > 1) {
			throw new InvalidResourceException("TravelDeslExec will always start from Grade -1");
		}

		usersRepository.save(users);

		employeeCheck = usersRepository.findById(users.getEmployeeid());
		if (employeeCheck.isPresent())

		{
			gradesServiceImpl.createGradesHistoryByEmployeeid(employeeCheck.get().getEmployeeid());
			return true;
		} else {
			return false;
		}
	}

//		createGradesHistoryByEmployeeid(employeeCheck.get().getEmployeeid());
	@Override
	public boolean deleteEmployeeById(int userId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Users> employeeCheck = usersRepository.findById(userId);
		if (employeeCheck.isPresent()) {
			usersRepository.delete(employeeCheck.get());
			employeeCheck = usersRepository.findById(userId);
			if (!employeeCheck.isPresent()) {
				return true;
			} else {
				return false;
			}
		} else {
			throw new ResourceNotFoundException("The Data for Employee id: " + userId + " is not found");
		}
	}

	@Override
	public boolean updateEmployee(int userId, Users users) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Users> employeeCheck = usersRepository.findById(userId);
		if (employeeCheck.isPresent()) {
			if (users.getEmployeeid() < 100000) {
				throw new InvalidResourceException("The entered employee id must have 6 digits for sure.");
			}

			if (!this.checkEmail(users.getEmailAddress())) {
				throw new InvalidResourceException("Your email id must have @cognizant.com for sure.");
			}

			if (gradesServiceImpl.updateGradesHistoryByEmployeeId(userId, users)) {

				usersRepository.save(users);
				return true;
			} else {
				return false;
			}
		} else {
			throw new ResourceNotFoundException(
					"The sent data is not there is database. Kindly check the data passed.");
		}
	}

	@Override
	public Users getEmployeeById(int userId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Users> employeeCheck = usersRepository.findById(userId);
		if (employeeCheck.isPresent()) {
			return (employeeCheck.get());
		} else {
			throw new ResourceNotFoundException("The Data for Employee id: " + userId + " is not found");
		}
	}

	private boolean checkEmail(String emailAddress) {
		if (!emailAddress.contains("@cognizant.com")) {
			return false;
		}
		return true;
	}

	public GradesHistory createGradesHistoryByEmployeeid(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
