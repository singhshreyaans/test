package com.employeetraveldesk.humanresources.service;

import java.util.List;

import com.employeetraveldesk.humanresources.exception.DuplicateResourceException;
import com.employeetraveldesk.humanresources.exception.InvalidResourceException;
import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.Users;

public interface UsersService {
	List<Users> getEmployees() throws ResourceNotFoundException;
	boolean addEmployee(Users users) throws DuplicateResourceException, InvalidResourceException;
	//boolean deleteEmployee(int id, Users users) throws ResourceNotFoundException;
	boolean updateEmployee(int id, Users users) throws ResourceNotFoundException;
	Users getEmployeeById(int userId) throws ResourceNotFoundException;
	boolean deleteEmployeeById(int userId) throws ResourceNotFoundException;

}
