package com.employeetraveldesk.humanresources.service.implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeetraveldesk.humanresources.exception.ResourceNotFoundException;
import com.employeetraveldesk.humanresources.model.Grades;
import com.employeetraveldesk.humanresources.repository.GradesRepository;
import com.employeetraveldesk.humanresources.service.GradesService;
@Service
public class GradesServiceImplementation implements GradesService {
	
	@Autowired
	GradesRepository gradesRepository;
	//ModelMapperList modelMapperList=new ModelMapperList();
	
	@Override
	public List<Grades> getGradesList() throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		List<Grades> grades=new ArrayList<Grades>();
		grades=gradesRepository.findAll();
		
		if(grades.size()==0) {
			throw new ResourceNotFoundException("No Resource in Grades. Check your Database!");
		}
		
		return grades;
	}

}
