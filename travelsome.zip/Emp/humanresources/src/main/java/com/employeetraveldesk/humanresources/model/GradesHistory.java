package com.employeetraveldesk.humanresources.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class GradesHistory {
	
	@Id
	private int id;
	private LocalDate assignedOn;
	
	@ManyToOne
	@JoinColumn(name="employeeid")
	private Users employeeid;
	
	
	public GradesHistory() {
    }

	
	public GradesHistory(int i, LocalDate now, Users users, Grades grades2) {
		// TODO Auto-generated constructor stub
	}
	public Users getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(Users employeeid) {
		this.employeeid = employeeid;
	}
	public Grades getGrades() {
		return grades;
	}
	public void setGrades(Grades grades) {
		this.grades = grades;
	}
	
	@ManyToOne
	@JoinColumn(name="gradeid")
	private Grades grades;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public LocalDate getAssignedOn() {
		return assignedOn;
	}
	public void setAssignedOn(LocalDate assignedOn) {
		this.assignedOn = assignedOn;
	}
	

}
