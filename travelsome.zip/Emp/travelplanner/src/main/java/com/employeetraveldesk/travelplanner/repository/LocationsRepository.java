package com.employeetraveldesk.travelplanner.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employeetraveldesk.travelplanner.entity.Locations;

//creating a spring data repository
public interface LocationsRepository  extends JpaRepository<Locations, Integer> {

}
