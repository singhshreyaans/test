package com.employeetraveldesk.travelplanner.service;

import com.employeetraveldesk.travelplanner.exception.DuplicateResourceException;
import com.employeetraveldesk.travelplanner.exception.InvalidResourceException;
import com.employeetraveldesk.travelplanner.exception.ResourceNotFoundException;
import com.employeetraveldesk.travelplanner.model.TravelRequestsDTO;


public interface TravelRequestsService {
	//to insert a new travel request
	int createTravelRequest(TravelRequestsDTO travelRequestsDTO) throws DuplicateResourceException, InvalidResourceException;
	//to return a request using hr id
	TravelRequestsDTO retrieveTravelRequestByHRid(int HRid) throws ResourceNotFoundException;
	//to return a request using request id
	TravelRequestsDTO retrieveTravelRequestById(int trid) throws ResourceNotFoundException;
	//to update a travel request
	boolean updateTravelRequestsById(int trid,TravelRequestsDTO travelRequestsDTO) throws ResourceNotFoundException, InvalidResourceException;
	int getCalculateBudget(TravelRequestsDTO travelRequestsDTO)
			throws DuplicateResourceException, InvalidResourceException;
}
