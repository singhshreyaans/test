package com.employeetraveldesk.travelplanner.service.implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeetraveldesk.travelplanner.entity.TravelBudgetAllocations;
import com.employeetraveldesk.travelplanner.entity.TravelRequests;
import com.employeetraveldesk.travelplanner.exception.DuplicateResourceException;
import com.employeetraveldesk.travelplanner.exception.InvalidResourceException;
import com.employeetraveldesk.travelplanner.exception.ResourceNotFoundException;
import com.employeetraveldesk.travelplanner.mapper.ModelMapper;
import com.employeetraveldesk.travelplanner.model.TravelRequestsDTO;
import com.employeetraveldesk.travelplanner.repository.TravelBudgetAllocationsRepository;
import com.employeetraveldesk.travelplanner.repository.TravelRequestsRepository;
import com.employeetraveldesk.travelplanner.service.TravelRequestsService;

@Service
public class TravelRequestServiceImplementation implements TravelRequestsService {
	
	@Autowired
	private TravelRequestsRepository travelRequestsRepository;

	private ModelMapper modelMapper=new ModelMapper();
	
	@Override
	public int createTravelRequest(TravelRequestsDTO travelRequestsDTO) throws DuplicateResourceException, InvalidResourceException {
		// TODO Auto-generated method stub
		TravelRequests travelRequest=modelMapper.convertDTOToEntity(travelRequestsDTO);
		Optional<TravelRequests> checkTravelRequests=travelRequestsRepository.findById(travelRequest.getRequestId());
		if(checkTravelRequests.isPresent()) {
			throw new DuplicateResourceException(
					"Resource is already available for Id : " + travelRequest.getRequestId());
		}
		else {
			travelRequestsRepository.save(travelRequest);
			return travelRequest.getRequestId();
		}
	}
	
	
	@Override
	public int getCalculateBudget(TravelRequestsDTO travelRequestsDTO) throws DuplicateResourceException, InvalidResourceException {
		TravelRequests travelRequest=modelMapper.convertDTOToEntity(travelRequestsDTO);
		Optional<TravelRequests> checkTravelRequests=travelRequestsRepository.findById(travelRequest.getRequestId());
		if(checkTravelRequests.isPresent()) {
			throw new DuplicateResourceException(
					"Resource is already available for Id : " + travelRequest.getRequestId());
		}
		else {
			travelRequestsRepository.save(travelRequest);
			return travelRequest.getToBeApprovedByHRId();
		}
		
		
	}
	@Override
	public TravelRequestsDTO retrieveTravelRequestByHRid(int HRid) throws ResourceNotFoundException{
		// TODO Auto-generated method stub
		TravelRequests checkTravelRequests=travelRequestsRepository.findByToBeApprovedByHRId(HRid);
		if(checkTravelRequests!=null) {
			return modelMapper.convertEntityToDTO(checkTravelRequests);
		}
		else {			
			throw new ResourceNotFoundException("Hr id not found");
		}
	}
	@Override
	public TravelRequestsDTO retrieveTravelRequestById(int trid) throws ResourceNotFoundException{
		// TODO Auto-generated method stub
		Optional<TravelRequests> checkTravelRequests=travelRequestsRepository.findById(trid);
		if(checkTravelRequests.isPresent()) {
			return modelMapper.convertEntityToDTO(checkTravelRequests.get());
		}
		else {			
			throw new ResourceNotFoundException("Travel Request Id not found");
		}
	}
	@Override
	public boolean updateTravelRequestsById(int trid, TravelRequestsDTO travelRequestsDTO) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<TravelRequests> checkTravelRequests=travelRequestsRepository.findById(trid);
		if(checkTravelRequests.isPresent()) {
			boolean check=travelRequestsRepository.save(modelMapper.convertDTOToEntity(travelRequestsDTO)) != null;
			return check;
		}
		else {			
			throw new ResourceNotFoundException("Travel Request Id not found");
		}
	}

}
