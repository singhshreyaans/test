package com.employeetraveldesk.travelplanner.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.employeetraveldesk.travelplanner.model.LocationsDTO;

@Service
public interface LocationsService {
	//to return all locations
	List<LocationsDTO> returnAllLocations();
}
