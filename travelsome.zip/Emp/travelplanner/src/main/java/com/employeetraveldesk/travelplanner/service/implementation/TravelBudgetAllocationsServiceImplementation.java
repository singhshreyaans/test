package com.employeetraveldesk.travelplanner.service.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.employeetraveldesk.travelplanner.entity.TravelBudgetAllocations;
import com.employeetraveldesk.travelplanner.entity.TravelRequests;
import com.employeetraveldesk.travelplanner.model.UsersDTO;
import com.employeetraveldesk.travelplanner.repository.TravelBudgetAllocationsRepository;
import com.employeetraveldesk.travelplanner.repository.TravelRequestsRepository;
import com.employeetraveldesk.travelplanner.service.TravelBudgetAllocationsService;
import com.google.common.base.Optional;


@Service
public class TravelBudgetAllocationsServiceImplementation implements TravelBudgetAllocationsService {
	
	@Autowired
	private TravelBudgetAllocationsRepository tba;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private TravelRequestsRepository t;
	
	@Override
	public TravelBudgetAllocations createBudget(TravelBudgetAllocations budget, int requestid){
		java.util.Optional<TravelRequests> travel = t.findById(requestid);
		TravelRequests tr = new TravelRequests();
		budget.setApprovedBudget(15000);
		System.out.println(budget.getApprovedBudget());
		UsersDTO u = restTemplate.getForObject("http://localhost:8090/Users/getUsers"+travel.get().getRaisedByEmployeeId(), UsersDTO.class);
		return tba.save(budget);
//		if(u.get.equalsIgnoreCase("Grade1")) 
//		{
//			budget.setApprovedBudget(10000);
//			System.out.println(budget.getApprovedBudget());
//		}
//		else if(u.getGrades.getGradeName().equalsIgnoreCase("Grade2")) {
//			budget.setApprovedBudget(120000);
//			System.out.println(budget.getApprovedBudget());
//		}
//		else
//		{
//			budget.setApprovedBudget(15000);
//			System.out.println(budget.getApprovedBudget());
//		}
////		
////		System.out.println(u.getEmployeeId());
////		System.out.println(u.getFirstName());
////		System.out.println(u.getLastName());
////		System.out.println(u.getEmailAddress);
//		
//		// UserDTO u = restTemplate.getForObject("https://localhost)
//		
//		return tba.save(budget);
//		
}
	@Override
	public List<TravelBudgetAllocations> getAllBudgetAllocation() {
		return tba.findAll();
	}
	
	
		
		
	}


