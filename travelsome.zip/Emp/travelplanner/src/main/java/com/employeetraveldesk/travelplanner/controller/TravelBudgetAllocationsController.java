package com.employeetraveldesk.travelplanner.controller;


import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.employeetraveldesk.travelplanner.entity.TravelBudgetAllocations;
import com.employeetraveldesk.travelplanner.service.TravelBudgetAllocationsService;

@RestController
@RequestMapping("/budget")
public class TravelBudgetAllocationsController {
	
	@Autowired
	private TravelBudgetAllocationsService tb;
	
	@PostMapping("/create/{requestid}")
	public ResponseEntity<TravelBudgetAllocations> saveEmployee(@RequestBody TravelBudgetAllocations budget, @PathVariable int requestid)
	{
		TravelBudgetAllocations createBudget = tb.createBudget(budget,requestid);
		return new ResponseEntity<>(createBudget,HttpStatus.CREATED);
	}
	
	@GetMapping("/getAllocatedBudget")
	public ResponseEntity<List<TravelBudgetAllocations>> getAllBudgetAllocationsDetails()
	{
		List<TravelBudgetAllocations> empList = tb.getAllBudgetAllocation();
		if(!empList.isEmpty()) {
			return new ResponseEntity<> (empList, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
		}
	}
	
	

}
