package com.employeetraveldesk.travelplanner.service;

import java.util.List;

import com.employeetraveldesk.travelplanner.entity.TravelBudgetAllocations;

public interface TravelBudgetAllocationsService {

	TravelBudgetAllocations createBudget(TravelBudgetAllocations budget, int requestid);
	List<TravelBudgetAllocations> getAllBudgetAllocation();
	
}
